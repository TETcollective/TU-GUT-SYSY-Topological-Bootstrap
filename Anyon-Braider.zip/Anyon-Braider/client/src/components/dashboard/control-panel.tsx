import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Pause, RotateCcw, Settings2, Zap } from "lucide-react";

interface ControlPanelProps {
  flux: number;
  setFlux: (v: number) => void;
  turbulence: number;
  setTurbulence: (v: number) => void;
  charge: number;
  setCharge: (v: number) => void;
  isRunning: boolean;
  setIsRunning: (v: boolean) => void;
}

export function ControlPanel({ 
  flux, setFlux, 
  turbulence, setTurbulence, 
  charge, setCharge,
  isRunning, setIsRunning
}: ControlPanelProps) {
  return (
    <div className="glass-panel p-6 rounded-xl space-y-8 h-full flex flex-col">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div className="space-y-1">
            <h2 className="text-lg font-bold font-sans tracking-wide flex items-center gap-2">
              <Settings2 className="w-4 h-4 text-primary" />
              SYSTEM CONTROLS
            </h2>
            <p className="text-xs text-muted-foreground font-mono">TU-GUT-SYSY v35</p>
        </div>
        <Badge variant="outline" className="font-mono text-[10px] border-primary/30 text-primary bg-primary/5">
            ONLINE
        </Badge>
      </div>

      <div className="space-y-6 flex-1">
        {/* Anyon Flux Control */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-medium text-foreground/80">Anyon Flux Density</Label>
            <span className="font-mono text-xs text-primary">{(flux * 100).toFixed(0)}%</span>
          </div>
          <Slider 
            value={[flux]} 
            onValueChange={(vals) => setFlux(vals[0])} 
            max={1} 
            step={0.01}
            className="[&>.relative>.absolute]:bg-primary"
          />
          <p className="text-[10px] text-muted-foreground leading-tight">
            Adjusts the propagation speed and density of the quasiparticles within the braiding manifold.
          </p>
        </div>

        {/* Turbulence Control */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-medium text-foreground/80">Ultraclean Turbulence</Label>
            <span className="font-mono text-xs text-secondary">Re: {(turbulence * 10000).toFixed(0)}</span>
          </div>
          <Slider 
            value={[turbulence]} 
            onValueChange={(vals) => setTurbulence(vals[0])} 
            max={1} 
            step={0.01}
             className="[&>.relative>.absolute]:bg-secondary"
          />
          <p className="text-[10px] text-muted-foreground leading-tight">
            Injects stochastic noise into the Hamiltonian path, simulating vacuum fluctuations.
          </p>
        </div>

        {/* Topological Charge Control */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-medium text-foreground/80">Topological Charge (Q)</Label>
            <span className="font-mono text-xs text-purple-400">Q = {charge.toFixed(2)}</span>
          </div>
          <Slider 
            value={[charge]} 
            onValueChange={(vals) => setCharge(vals[0])} 
            max={2} 
            step={0.1}
             className="[&>.relative>.absolute]:bg-purple-500"
          />
        </div>

        {/* Switches */}
        <div className="space-y-4 pt-4 border-t border-white/5">
            <div className="flex items-center justify-between">
                <Label htmlFor="entanglement" className="text-xs font-mono">QUANTUM ENTANGLEMENT</Label>
                <Switch id="entanglement" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
                <Label htmlFor="cherenkov" className="text-xs font-mono">CHERENKOV GLOW</Label>
                <Switch id="cherenkov" defaultChecked />
            </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-4">
        <Button 
            className={`w-full font-mono ${isRunning ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20' : 'bg-primary/10 text-primary hover:bg-primary/20'}`}
            variant="outline"
            onClick={() => setIsRunning(!isRunning)}
        >
            {isRunning ? <><Pause className="mr-2 h-4 w-4" /> HALT</> : <><Play className="mr-2 h-4 w-4" /> INITIATE</>}
        </Button>
        <Button variant="outline" className="w-full font-mono hover:bg-white/5">
            <RotateCcw className="mr-2 h-4 w-4" /> RESET
        </Button>
      </div>
    </div>
  );
}
