import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { Card } from "@/components/ui/card";
import { useEffect, useState } from "react";

const generateData = (count: number) => {
    return Array.from({ length: count }).map((_, i) => ({
        time: i,
        entropy: 40 + Math.random() * 20,
        fidelity: 85 + Math.random() * 15,
        braids: 10 + Math.random() * 50
    }));
};

interface MetricsGridProps {
    isRunning: boolean;
}

export function MetricsGrid({ isRunning }: MetricsGridProps) {
    const [data, setData] = useState(generateData(20));

    useEffect(() => {
        if (!isRunning) return;
        const interval = setInterval(() => {
            setData(prev => {
                const newPoint = {
                    time: prev[prev.length - 1].time + 1,
                    entropy: 40 + Math.random() * 20 + Math.sin(Date.now() / 1000) * 10,
                    fidelity: 85 + Math.random() * 10,
                    braids: Math.abs(Math.sin(Date.now() / 500) * 100)
                };
                return [...prev.slice(1), newPoint];
            });
        }, 1000);
        return () => clearInterval(interval);
    }, [isRunning]);

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full">
            <Card className="glass-panel p-4 flex flex-col border-none bg-black/20">
                <div className="mb-2 flex justify-between items-end">
                    <span className="text-xs font-mono text-muted-foreground">VON NEUMANN ENTROPY</span>
                    <span className="text-xl font-mono text-primary font-bold">{data[data.length - 1].entropy.toFixed(2)} S</span>
                </div>
                <div className="flex-1 min-h-[100px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data}>
                            <defs>
                                <linearGradient id="colorEntropy" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                            <Area 
                                type="monotone" 
                                dataKey="entropy" 
                                stroke="#06b6d4" 
                                strokeWidth={2}
                                fillOpacity={1} 
                                fill="url(#colorEntropy)" 
                                isAnimationActive={false}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </Card>

            <Card className="glass-panel p-4 flex flex-col border-none bg-black/20">
                <div className="mb-2 flex justify-between items-end">
                    <span className="text-xs font-mono text-muted-foreground">BRAIDING FIDELITY</span>
                    <span className="text-xl font-mono text-purple-400 font-bold">{data[data.length - 1].fidelity.toFixed(1)}%</span>
                </div>
                <div className="flex-1 min-h-[100px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data}>
                            <defs>
                                <linearGradient id="colorFidelity" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#c084fc" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#c084fc" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                            <Area 
                                type="monotone" 
                                dataKey="fidelity" 
                                stroke="#c084fc" 
                                strokeWidth={2}
                                fillOpacity={1} 
                                fill="url(#colorFidelity)" 
                                isAnimationActive={false}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </Card>

            <Card className="glass-panel p-4 flex flex-col border-none bg-black/20">
                <div className="mb-2 flex justify-between items-end">
                    <span className="text-xs font-mono text-muted-foreground">INTERFERENCE PATTERN</span>
                    <span className="text-xl font-mono text-emerald-400 font-bold">{data[data.length - 1].braids.toFixed(0)} Hz</span>
                </div>
                <div className="flex-1 min-h-[100px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data}>
                            <defs>
                                <linearGradient id="colorBraids" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#34d399" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#34d399" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                            <Area 
                                type="step" 
                                dataKey="braids" 
                                stroke="#34d399" 
                                strokeWidth={2}
                                fillOpacity={1} 
                                fill="url(#colorBraids)" 
                                isAnimationActive={false}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </Card>
        </div>
    );
}
