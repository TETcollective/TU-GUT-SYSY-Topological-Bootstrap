import { useEffect, useRef, useState } from "react";

interface BraiderVizProps {
  flux: number;
  turbulence: number;
  charge: number;
}

export function BraiderViz({ flux, turbulence, charge }: BraiderVizProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [fps, setFps] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;
    let lastTime = performance.now();
    let frameCount = 0;
    let lastFpsTime = lastTime;

    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || 800;
      canvas.height = canvas.parentElement?.clientHeight || 600;
    };
    window.addEventListener("resize", resize);
    resize();

    // 3D Point class
    class Point3D {
      x: number;
      y: number;
      z: number;
      color: string;
      offset: number;
      
      constructor(offset: number, color: string) {
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.offset = offset;
        this.color = color;
      }

      update(t: number, flux: number, turbulence: number, charge: number) {
        // Braiding Lissajous 3D
        // Complex torus knot-like movement
        const speed = 0.5 + flux;
        
        // Base orbit
        const r1 = 150 + Math.sin(t * 0.5) * 50;
        const r2 = 50 * charge;
        
        // Turbulence noise
        const noise = Math.sin(t * 5 + this.offset) * (turbulence * 40);

        // Knot equation components
        const k = 3; // symmetry
        const phi = t * speed + this.offset;
        
        this.x = (r1 + r2 * Math.cos(k * phi)) * Math.cos(phi) + noise;
        this.y = (r1 + r2 * Math.cos(k * phi)) * Math.sin(phi) + noise;
        this.z = r2 * Math.sin(k * phi) + noise;
      }
    }

    const particles: Point3D[] = [];
    const particleCount = 200;

    for (let i = 0; i < particleCount; i++) {
      particles.push(new Point3D(
        (i / particleCount) * Math.PI * 2 * 10, // Spread out phase
        i % 2 === 0 ? "#06b6d4" : "#8b5cf6"
      ));
    }

    const draw = () => {
      const now = performance.now();
      time += 0.005 + (flux * 0.005);

      frameCount++;
      if (now - lastFpsTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastFpsTime = now;
      }

      // Trail effect
      ctx.fillStyle = "rgba(2, 4, 16, 0.15)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Update all particles
      particles.forEach(p => p.update(time, flux, turbulence, charge));

      // Sort by Z for depth
      particles.sort((a, b) => a.z - b.z);

      // Draw lines between neighbors (simulating the braid strands)
      ctx.lineWidth = 1;
      
      // Draw individual particles/strands
      particles.forEach((p, i) => {
        // Perspective projection
        const fov = 300;
        const scale = fov / (fov + p.z);
        const x2d = centerX + p.x * scale;
        const y2d = centerY + p.y * scale;
        
        // Size based on depth
        const size = Math.max(0.5, 3 * scale);
        
        // Opacity based on depth
        const alpha = Math.max(0.2, Math.min(1, (p.z + 100) / 200 + 0.5));

        ctx.beginPath();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.arc(x2d, y2d, size, 0, Math.PI * 2);
        ctx.fill();
        
        // Connect to "previous" particle to form lines if we want strands
        // But since we are sorting by Z every frame, the "previous" in array changes. 
        // We should instead connect based on original index, but for this viz, 
        // let's just draw flowing points or connect nearby points.
        
        // Simple glow
        if (turbulence > 0.5 && Math.random() > 0.9) {
             ctx.shadowBlur = 10;
             ctx.shadowColor = p.color;
             ctx.fillRect(x2d, y2d, size*2, size*2);
             ctx.shadowBlur = 0;
        }
      });
      ctx.globalAlpha = 1;

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [flux, turbulence, charge]);

  return (
    <div className="relative w-full h-full rounded-lg overflow-hidden glass-panel border border-primary/20">
      <div className="absolute top-4 left-4 z-10 pointer-events-none">
        <h3 className="text-primary font-mono text-xs uppercase tracking-widest mb-1">Manifold Projection</h3>
        <div className="flex items-center gap-2">
           <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"/>
           <span className="text-xs text-muted-foreground font-mono">LIVE • {fps} FPS</span>
        </div>
      </div>
      <canvas ref={canvasRef} className="w-full h-full block" />
      
      {/* Overlay Data */}
      <div className="absolute bottom-4 right-4 z-10 font-mono text-xs text-right pointer-events-none space-y-1">
        <div className="text-muted-foreground">FLUX DENSITY</div>
        <div className="text-primary text-lg">{(flux * 10.42).toFixed(4)} TeV</div>
      </div>
    </div>
  );
}
