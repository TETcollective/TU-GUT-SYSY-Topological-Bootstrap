import { useEffect, useRef, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";

const LOG_MESSAGES = [
  "Initializing Topological Bootstrap...",
  "Anyon flux stabilized at 0.54 TeV",
  "Vacuum expectation value non-zero",
  "Hamiltonian diagonalization complete",
  "Cherenkov radiation detected in sector 7G",
  "Braiding fidelity optimal",
  "Entropy increasing in subsystem B",
  "Quantum error correction active",
  "Sycamore processor synchronization: 99.9%",
  "Majorana zero modes isolated",
  "Winding number calculated: W=3",
  "Non-Abelian statistics confirmed",
  "Fusion rules applied: σ × σ = I + ψ",
  "Topological charge conservation check... PASS",
  "Ultraclean turbulence injection: NOMINAL"
];

export function SystemLog() {
  const [logs, setLogs] = useState<string[]>(["SYSTEM BOOT SEQUENCE INITIATED..."]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const msg = LOG_MESSAGES[Math.floor(Math.random() * LOG_MESSAGES.length)];
      const timestamp = new Date().toISOString().split('T')[1].slice(0, 12);
      setLogs(prev => [`[${timestamp}] ${msg}`, ...prev].slice(0, 50));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="glass-panel p-4 rounded-xl h-full flex flex-col">
      <h3 className="text-xs font-mono text-muted-foreground uppercase mb-2 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-primary animate-pulse"/>
        System Kernel Log
      </h3>
      <ScrollArea className="flex-1 w-full h-[150px] font-mono text-[10px] text-foreground/70">
        <div className="space-y-1">
          {logs.map((log, i) => (
            <div key={i} className="border-l-2 border-primary/20 pl-2 hover:bg-white/5 hover:text-primary transition-colors cursor-default">
              {log}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
