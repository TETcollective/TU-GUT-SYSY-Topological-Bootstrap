import { useState } from "react";
import { BraiderViz } from "@/components/dashboard/braider-viz";
import { ControlPanel } from "@/components/dashboard/control-panel";
import { MetricsGrid } from "@/components/dashboard/metrics-grid";
import { SystemLog } from "@/components/dashboard/system-log";
import { Activity, Cpu, Database, Network } from "lucide-react";
import generatedImage from '@assets/generated_images/quantum_turbulence_background.png';

export default function Dashboard() {
  const [flux, setFlux] = useState(0.5);
  const [turbulence, setTurbulence] = useState(0.2);
  const [charge, setCharge] = useState(1.0);
  const [isRunning, setIsRunning] = useState(true);

  return (
    <div className="min-h-screen w-full bg-background text-foreground overflow-hidden flex flex-col font-sans selection:bg-primary/20">
      {/* Background Image Layer */}
      <div 
        className="fixed inset-0 z-0 opacity-20 pointer-events-none"
        style={{
            backgroundImage: `url(${generatedImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            mixBlendMode: 'screen'
        }}
      />
      
      {/* Header */}
      <header className="h-16 border-b border-white/5 bg-black/20 backdrop-blur-md flex items-center justify-between px-6 z-10 sticky top-0 shrink-0">
        <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center border border-primary/40">
                <Network className="w-5 h-5 text-primary" />
            </div>
            <div>
                <h1 className="text-xl font-bold tracking-tight text-white leading-none">TU-GUT-SYSY <span className="text-primary">v35</span></h1>
                <p className="text-[10px] text-muted-foreground font-mono tracking-wider">ETERNAL ANYON BRAIDER PROTOCOL</p>
            </div>
        </div>

        <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/5">
                <Activity className="w-3 h-3 text-green-500" />
                <span className="text-xs font-mono text-muted-foreground">SYSTEM STABLE</span>
            </div>
            <div className="text-right">
                <p className="text-[10px] text-muted-foreground font-mono">SESSION ID</p>
                <p className="text-xs font-mono text-primary">0x4F92-AB12</p>
            </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 z-10 grid grid-cols-12 gap-6 h-[calc(100vh-64px)] overflow-hidden">
        
        {/* Left Column - Controls (3 cols) */}
        <div className="col-span-12 lg:col-span-3 h-full flex flex-col gap-6 overflow-hidden">
            <div className="flex-none">
                 <ControlPanel 
                    flux={flux} 
                    setFlux={setFlux}
                    turbulence={turbulence}
                    setTurbulence={setTurbulence}
                    charge={charge}
                    setCharge={setCharge}
                    isRunning={isRunning}
                    setIsRunning={setIsRunning}
                />
            </div>
            
            <div className="flex-1 min-h-0">
                 <SystemLog />
            </div>
        </div>

        {/* Right Column - Viz & Metrics (9 cols) */}
        <div className="col-span-12 lg:col-span-9 flex flex-col gap-6 h-full overflow-hidden">
            
            {/* Viz Canvas - Flexible height */}
            <div className="flex-1 min-h-[400px]">
                <BraiderViz flux={flux} turbulence={turbulence} charge={charge} />
            </div>

            {/* Metrics Row - Fixed height */}
            <div className="h-[200px] shrink-0">
                <MetricsGrid isRunning={isRunning} />
            </div>

        </div>

      </main>
    </div>
  );
}
